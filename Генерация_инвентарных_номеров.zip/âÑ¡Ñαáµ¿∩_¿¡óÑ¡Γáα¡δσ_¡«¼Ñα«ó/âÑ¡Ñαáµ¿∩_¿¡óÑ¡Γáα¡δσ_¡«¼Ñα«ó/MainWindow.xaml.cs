﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using Microsoft.Office.Interop.Word; 
using Word = Microsoft.Office.Interop.Word;

namespace Генерация_инвентарных_номеров
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : System.Windows.Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //генерация инвентарного номера
        private void GenerateButton_Click(object sender, RoutedEventArgs e)
        {
            string characters = "АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЩЪЬЫЭЮЯ012345678901234567890123456789";
            Random rnd = new Random();
            StringBuilder inventoryNumber = new StringBuilder();

            int length = rnd.Next(5, 20); 

            for (int i = 0; i < length; i++)
            {
                int index = rnd.Next(0, characters.Length);
                inventoryNumber.Append(characters[index]);
            }

           
            inventoryNumber[0] = char.ToUpper(inventoryNumber[0]);
            for (int i = 0; i < inventoryNumber.Length; i++)
            {
                inventoryNumber[i] = char.ToUpper(inventoryNumber[i]);
            }

            ResultTextBox.Text = inventoryNumber.ToString();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            SaveInventoryNumberToCSV(ResultTextBox.Text);
        }
        private void SaveInventoryNumberToCSV(string inventoryNumber)
        {
            try
            {
                // Создаем файл CSV
                string filePath = "inventory_numbers.csv";
                StreamWriter writer = new StreamWriter(filePath, true, Encoding.UTF8); 

                // Запишем инвентарный номер в файл
                writer.WriteLine(inventoryNumber);

                // Закроем файл
                writer.Close();

                MessageBox.Show("Инвентарный номер сохранен в файл " + filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении инвентарного номера: " + ex.Message);
            }
        }

        private void SaveToImage_Click(object sender, RoutedEventArgs e)
        {
            SaveInventoryNumberToImage(ResultTextBox.Text);
        }

        private void SaveInventoryNumberToImage(string inventoryNumber)
        {
            try
            {
                // Создаем пустой Bitmap для получения контекста рисования
                Bitmap bmp = new Bitmap(1, 1);
                Graphics g = Graphics.FromImage(bmp);

                // Определяем шрифт, цвет и размер текста
                System.Drawing.Font font = new System.Drawing.Font("Arial", 12);
                System.Drawing.Brush brush = new SolidBrush(System.Drawing.Color.Black);
                SizeF textSize = g.MeasureString(inventoryNumber, font);

                //Создаем новое изображение с подходящим размером
                bmp = new Bitmap((int)textSize.Width + 10, (int)textSize.Height + 10);
                g = Graphics.FromImage(bmp);

                // Рисуем текст на изображении
                g.DrawString(inventoryNumber, font, brush, 5, 5);

                // Сохраняем изображение
                string filePath = "inventory_number.png";
                bmp.Save(filePath, ImageFormat.Png);

                // Выводим сообщение об успешном сохранении
                MessageBox.Show("Инвентарный номер сохранен в картинку " + filePath);
            }
            catch (Exception ex)
            {
                //Обработка ошибок
                MessageBox.Show("Ошибка при сохранении инвентарного номера в картинку: " + ex.Message);
            }
        }

        private void SaveToWord_Click(object sender, RoutedEventArgs e)
        {
            SaveInventoryNumberToWord(ResultTextBox.Text);
        }
        private void SaveInventoryNumberToWord(string inventoryNumber)
        {
            try
            {
                // Создаем новый документ Word
                Word.Application wordApp = new Word.Application();
                Word.Document doc = wordApp.Documents.Add();

                // Вставляем текст в документ
                Word.Paragraph para = doc.Content.Paragraphs.Add();
                para.Range.Text = inventoryNumber;

                // Сохраняем документ
                string filePath = "inventory_number.docx";
                doc.SaveAs2(filePath);

                // Закрываем документ и приложение Word
                doc.Close();
                wordApp.Quit();

                MessageBox.Show("Инвентарный номер сохранен в файл " + filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении инвентарного номера в Word: " + ex.Message);
            }
        }
    }
}
